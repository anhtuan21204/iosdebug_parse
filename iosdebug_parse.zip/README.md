# iosdebug_parse
Small script to parse iosdebug.log file for mart
