<?php
	const CASH_KEY = '58CASH';
	const CARD_KEY = '52CARD';
	const GIFT_KEY = '51GIFT';
	const ENTER_KEY = '3ENTER';
	const SIGNOFF = '77CASHIER OFF';
	const TIME_LENGTH = 19;
	const READER_DEVICE_LENGTH = 17;
	const COMMAND_READ_LENGTH = 35;
	const CONTENT_READ_LENGTH = 2;

	$dictionary = array(
		'KBD' => 'Keyboard',
		'GUN SCANNER' => 'Scan tay',
		'SLOT SCANNER' => 'Scan b�n',

	);	