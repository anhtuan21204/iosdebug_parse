<?php
const JOURNAL_IP = '10.164.1.33';